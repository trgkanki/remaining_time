# Remaining Time 2.1 - Configuration

## showAtBottom

- When this is true, the progress bar will show at the bottom.
- Default: false

## useDarkMode

- When this is true, bar inverts its color. Black background and white text.